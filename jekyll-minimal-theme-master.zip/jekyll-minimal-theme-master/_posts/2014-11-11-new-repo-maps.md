---
layout: post
title: "New Repo /maps - Free Full-Screen Interactive Beer Maps w/ Brewery Listings"
---

Added a new repo, that is, `/maps` for hosting 'full-screen'
interactive beer maps with brewery listings.

See an example [beer map for Austria](http://openbeer.github.io/maps/at) (~200 breweries n brewpubs)
live or [check the source using](https://github.com/openbeer/maps) the mapbox.js mapping library.
