---
layout: post
title: "New Repo - Bayern (Baviria) - incl. European Beer Stars 2011, 2012, 2013"
---

Moved all beer, brewpub n brewery data for Bayern
(Baviria) to its own repo, that is, [`openbeer/by-bayern`](https://github.com/openbeer/by-bayern).

Also includes all European Beer Star winners from Bayern
(Baviria) for the years 2011, 2012 and 2013. Cheers. Prost.

